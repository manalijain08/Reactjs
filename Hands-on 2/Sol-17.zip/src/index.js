import React from "react"
import ReactDOM from "react-dom"

function Project() {
    return(
        <div>
            <nav className="nav">
                <img src="./logo192.png" className="nav-logo"/>
                <h3 className="nav-heading">ReactFacts</h3>
                <h4 className="nav-subheading">React Course - Project 1</h4>
            </nav>

            <main className="main">
                <h1>Fun facts about React</h1>
                <ul>
                    <li>Was first released in 2013</li>
                    <li>Was originally created by Jordan Walke</li>
                    <li>Has well over 100k stars on GitHub</li>
                    <li>Is maintained by Facebook</li>
                    <li>Powers thousands of enterprise apps, including mobile apps</li>
                </ul>
            </main>
        </div>
    )
}

ReactDOM.render(<Project/>, document.getElementById("root"))