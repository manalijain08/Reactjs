import React from "react"
import ReactDOM from "react-dom"

function Page() {
    return (
        <div>
            <p>Why learn React</p>
            <ol>
               <li>React is flexible and efficient</li>
               <li> React developers are in demand</li>
               <li> React doesn't take long to learn</li>
           </ol>
        </div>
    )
}

ReactDOM.render(<Page/>, document.getElementById("root"))