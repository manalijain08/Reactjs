import React from "react"
import ReactDOM from "react-dom"
import Header from "./Components/Header"
import Footer from "./Components/Footer"
import MainComponent from "./Components/MainComponent"



function Page() {
    return(
        <div>
            <Header/>
            <MainComponent/>
            <Footer/>
        </div>
    )
}

ReactDOM.render(<Page/>, document.getElementById("root"))