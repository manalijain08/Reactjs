import React from "react"

function MainComponent() {
    return (
        <div>
            <h1>Why learn React</h1>
            <ol>
               <li>React is flexible and efficient</li>
               <li> React developers are in demand</li>
               <li> React doesn't take long to learn</li>
           </ol>
        </div>
    )
}

export default MainComponent