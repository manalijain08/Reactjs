import React from "react"

function Footer() {
    return(
        <footer>
           <small>"&copy; Jain  development. All rights reserved."</small>
        </footer>
    )
}

export default Footer