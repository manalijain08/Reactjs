import React from "react"
import ReactDOM from "react-dom"

function Page() {
    return (
        <div>
            <header>
                <nav>
                    <img src="./logo192.png"  width="40px" />
                </nav>
            </header>
            <h1>Why learn React</h1>
            <ol>
               <li>React is flexible and efficient</li>
               <li> React developers are in demand</li>
               <li> React doesn't take long to learn</li>
           </ol>
           <footer>
                <small>"&copy; Jain  development. All rights reserved."</small>
           </footer>
        </div>
    )
}

ReactDOM.render(<Page/>, document.getElementById("root"))