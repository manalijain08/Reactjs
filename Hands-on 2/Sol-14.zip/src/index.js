import React from "react"
import ReactDOM from "react-dom"

function Header() {
    return(
        <header>
            <nav>
                <img src="./logo192.png"  width="40px" />
            </nav>
       </header>
    )
}

function MainComponent() {
    return (
        <div>
            <h1>Why learn React</h1>
            <ol>
               <li>React is flexible and efficient</li>
               <li> React developers are in demand</li>
               <li> React doesn't take long to learn</li>
           </ol>
        </div>
    )
}

function Footer() {
    return(
        <footer>
           <small>"&copy; Jain  development. All rights reserved."</small>
        </footer>
    )
}

function Page() {
    return(
        <div>
            <Header/>
            <MainComponent/>
            <Footer/>
        </div>
    )
}

ReactDOM.render(<Page/>, document.getElementById("root"))