import React from 'react';
import Navbar from './Components/Navbar';


function App() {
  return (
    <div>
      <Navbar/>
    </div>
  )
}

export default App;
