const page = (
    <div>
        <p>React App</p>
        <h1>Hello from React App</h1>
    </div>
    
)

document.getElementById("root").append(page)