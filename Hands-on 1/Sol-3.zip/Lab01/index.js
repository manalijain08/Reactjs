function page() {
    return(
        <ul>
            <li>Jsx</li>
            <li>Components</li>
            <li>Vitual DOM</li>
            <li>Simplicity</li>
            <li>Performance</li>
        </ul>
    )
}

ReactDOM.render(<div><Page/></div>, document.getElementById("root"))