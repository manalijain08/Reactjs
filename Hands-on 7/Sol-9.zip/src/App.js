import React from "react"
import Headers from "./components/Header"
import Meme from "./Meme"
/**
 * Challenge: Build the Header component
 */
export default function App() {
    return <div>
        {/* <h1>Hello world!</h1> */}
        <Headers/>
        <Meme/>
        </div>
}
